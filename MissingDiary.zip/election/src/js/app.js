App = {
  webProvider: null,
  contracts: {},
  account: '0x0',

  init: function () {
    return App.initWeb();
  },
  initWeb: function () {
    // if an ethereum provider instance is already provided by metamask
    const provider = window.ethereum
    if (provider) {
      // currently window.web3.currentProvider is deprecated for known security issues.
      // Therefore it is recommended to use window.ethereum instance instead
      App.webProvider = provider;
    }
    else {
      $("#loader-msg").html('No metamask ethereum provider found')
      console.log('No Ethereum provider')
      // specify default instance if no web3 instance provided
      App.webProvider = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
    }
    return App.initContract();
  },

  initContract: function () {
    $.getJSON("Election.json", function (election) {
      // instantiate a new truffle contract from the artifict
      App.contracts.Election = TruffleContract(election);
      // connect provider to interact with contract
      App.contracts.Election.setProvider(App.webProvider);
      App.listenForEvents();
      return App.render();
    })
  },

  render: async function () {
    let electionInstance;
    const loader = $("#loader");
    const content = $("#content");

    loader.show();
    content.hide();
    // load account data
    if (window.ethereum) {
      try {
        // recommended approach to requesting user to connect mmetamask instead of directly getting the accounts
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        App.account = accounts;
        $("#accountAddress").html("Your Account: " + App.account);
      } catch (error) {
        if (error.code === 4001) {
          // User rejected request
          console.warn('user rejected')
        }
        $("#accountAddress").html("Your Account: Not Connected");
        console.error(error);
      }
    }
    //load contract ddata
    App.contracts.Election.deployed()
      .then(function (instance) {
        electionInstance = instance;
        return electionInstance.missing_persons_count();
      })
      .then(function (missing_persons_count) {
        var candidatesResults = $("#candidatesResults");
        candidatesResults.empty();
        var candidatesSelect = $("#candidatesSelect");
        candidatesSelect.empty();
        var division_order = $("#division_order");
        division_order.empty();
        var mean = $("#mean");
        mean.empty();
        var division_name = ["Dhaka", "Sylhet", "Khulna", "Barisal", "Mymensingh", "Rangpur", "Rajshahi", "Chattogram"];
        var division_count = [0, 0, 0, 0, 0, 0, 0, 0];
        for (let i = 1; i <= missing_persons_count; i++) {
          electionInstance.missing_persons(i)
            .then(function (missing_person) {
              var name = missing_person[0];
              var age = missing_person[1];
              var height = missing_person[2];
              var description = missing_person[3];
              var division = missing_person[4];
              // console.log(division_name.indexOf(missing_person[4]));
              division_count[division_name.indexOf(missing_person[4])]++;
              //console.log(division_count);
              if (i == missing_persons_count) {
                console.log("outside for");
                console.log(division_count);
                division_count.sort();
                var temp_array = [];
                var tmp = "";
                var n = 0;
                for (let i = 0; i < 8; i++) {
                  if ((i != 7) && (division_count[i]!=0)) {
                    tmp += division_count[i] + ", ";
                    n++;
                    temp_array.push(division_count[i]);
                  } else if ((i == 7) && (division_count[i]!=0)){
                    tmp += division_count[i];
                    n++;
                    temp_array.push(division_count[i]);
                  }
                }
                division_order.append(tmp);

                if (n%2 == 0){
                  mean.append("Median = " + (temp_array[(n/2)-1] + temp_array[((n/2)+1)-1]) / 2);
                }else{
                  mean.append("Median = " + (temp_array[((n+1)/2)-1]));
                }
                console.log(mean);
                console.log(division_order);
              }
              var contact = missing_person[5];
              console.log("inside for");
              console.log(division_count);
              // render results
              var candidateTemplate = "<tr><th>" + name + "</th><td>" + age + "</td><td>" + height + "</td><td>" + description + "</td><td>" + division + "</td><td>" + contact + "</td></tr>"
              candidatesResults.append(candidateTemplate);
            });
        }
        return electionInstance.voters(App.account);
      })
      .then(function (hasVoted) {
        // don't allow user to vote
        if (hasVoted) {
          $("form").hide()
        }
        loader.hide();
        content.show();
      })
      .catch(function (error) {
        console.warn(error)
      });
  },
  // casting vote
  castVote: function () {
    let name = $("#name").val();
    let age = $("#age").val();
    let height = $("#height").val();
    let description = $("#description").val();
    let division = $("#division").val();
    let contact = $("#contact").val();
    App.contracts.Election.deployed()
      .then(function (instance) {
        console.log(instance)
        return instance.update(name, age, height, description, division, contact, { from: App.account[0] })
      })
      .then(function (result) {
        // wait for voters to update vote
        console.log({ result })
        // content.hide();
        // loader.show();
      })
      .catch(function (err) {
        console.error(err)
      })
  },
  //sort by division
  sort: function () {
    let search_by_division = $("#search_division").val();
    App.contracts.Election.deployed()
      .then(function (instance) {
        electionInstance = instance;
        return electionInstance.missing_persons_count();
      })
      .then(function (missing_persons_count) {
        var candidatesResults = $("#candidatesResults");
        candidatesResults.empty();
        for (let i = 1; i <= missing_persons_count; i++) {
          electionInstance.missing_persons(i)
            .then(function (missing_person) {
              console.log(missing_person[4])
              console.log(search_by_division)
              if (missing_person[4] == search_by_division) {
                var name = missing_person[0];
                var age = missing_person[1];
                var height = missing_person[2];
                var description = missing_person[3];
                var division = missing_person[4];
                var contact = missing_person[5];
                // render results
                var candidateTemplate = "<tr><th>" + name + "</th><td>" + age + "</td><td>" + height + "</td><td>" + description + "</td><td>" + division + "</td><td>" + contact + "</td></tr>"
                candidatesResults.append(candidateTemplate);
              }
            });
        }
        return electionInstance.voters(App.account)
      })
      .then(function (hasVoted) {
        // don't allow user to vote
        if (hasVoted) {
          $("form").hide()
        }
        loader.hide();
        content.show();
      })
      .catch(function (error) {
        console.warn(error)
      });
  },
  // voted event
  listenForEvents: function () {
    App.contracts.Election.deployed()
      .then(function (instance) {
        instance.votedEvent({}, {
          fromBlock: 0,
          toBlock: "latests"
        })
          .watch(function (err, event) {
            console.log("Triggered", event);
            // reload page
            App.render()
          })
      })
  }
}

$(function () {
  $(window).load(function () {
    App.init();
  });
});